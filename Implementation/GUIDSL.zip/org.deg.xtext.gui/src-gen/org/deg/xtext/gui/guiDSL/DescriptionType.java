/**
 */
package org.deg.xtext.gui.guiDSL;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Description Type</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.deg.xtext.gui.guiDSL.GuiDSLPackage#getDescriptionType()
 * @model
 * @generated
 */
public interface DescriptionType extends EObject
{
} // DescriptionType
