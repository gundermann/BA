/**
 */
package org.deg.xtext.gui.guiDSL;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Complex Component</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.deg.xtext.gui.guiDSL.GuiDSLPackage#getComplexComponent()
 * @model
 * @generated
 */
public interface ComplexComponent extends DescriptionType
{
} // ComplexComponent
